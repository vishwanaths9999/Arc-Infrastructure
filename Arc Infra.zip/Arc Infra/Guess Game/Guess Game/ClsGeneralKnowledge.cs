﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Guess_Game
{
    class ClsGeneralKnowledge:IGuessGame
    {
        public string Question { get; set; }

        public String Clue1 { get; set; }

        public String Clue2 { get; set; }

        public String Clue3 { get; set; }

        public String Correctanswer { get; set; }

        public void DisplayAnswer()
        {
            Console.WriteLine("Correct Answer is {0} ", Correctanswer);
            Console.ReadLine();
        }
        public void DisplayQuestion()
        {
            Console.WriteLine("Question is {0} ", Question);
            Console.ReadLine();
        }

        public void DisplayClues()
        {
            Console.WriteLine("Clue1 is {0} ", Clue1);
            Console.ReadLine();
            Console.WriteLine("Clue2 is {0}", Clue2);
            Console.ReadLine();

            Console.WriteLine("Clue3 is {0}", Clue3);
            Console.ReadLine();


        }


    }
}
