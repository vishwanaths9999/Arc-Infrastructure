﻿using System;

namespace Guess_Game
{
    class Program
    {
        static void Main(string[] args)
        {
            ClsSports SportsQuestion = new ClsSports();

            SportsQuestion.Question = "Who won the Cricket world cup in 2019";
            SportsQuestion.Clue1 = "Hosted country won the cup";
            SportsQuestion.Clue2 = "Won for the first time in history";
            SportsQuestion.Clue3 = "Eoin Morgan is the captain";
            SportsQuestion.Correctanswer = "England";
            SportsQuestion.DisplayQuestion();
            SportsQuestion.DisplayClues();
            SportsQuestion.DisplayAnswer();

            ClsGeneralKnowledge GKQuestion = new ClsGeneralKnowledge();
            GKQuestion.Question = "Which country features a maple leaf on its flag";
            GKQuestion.Clue1 = "It is a country in the northern part of North America";
            GKQuestion.Clue2 = "It is world's second-largest country by total area";
            GKQuestion.Clue3 = " Prime minister is Justin Trudeau";
            GKQuestion.Correctanswer = "Canada";
            GKQuestion.DisplayQuestion();
            GKQuestion.DisplayClues();
            GKQuestion.DisplayAnswer();

        }
        
    }
}
