﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Guess_Game
{
    interface IGuessGame
    {
        string Question { get; set; }
        String Clue1 { get; set; }
        string Clue2 { get; set; }
        string Clue3 { get; set; }
        String Correctanswer { get; set; }
        void  DisplayAnswer();

        void DisplayQuestion();
        void DisplayClues();

        
        
    }
}
